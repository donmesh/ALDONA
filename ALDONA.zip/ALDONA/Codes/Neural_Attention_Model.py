import tensorflow as tf
from Algebra_Operators import matrix_tensor_product, tensor_tensor_product
from Attention_Modules import context_attention_module

def DBGRU(E, E_LS, E_RS, v_a, v_s, mask_left, mask_aspect, mask_right, mask_sentence, mask_left_with_aspect, mask_right_with_aspect, Y, weights, keep_prob, seed):
    S = tf.shape(E)[0]
    d = tf.shape(E)[1]
    N = tf.shape(E)[2]
    nr_cat = tf.shape(Y)[1]
    
    ############### Bidirectional Context Attention Mechanism #################
    ## Attention weights (S x N)                                                
    beta = context_attention_module(E_LS, E_RS, weights, mask_left, mask_aspect, 
                                    mask_right, mask_left_with_aspect, 
                                    mask_right_with_aspect, mask_sentence, 
                                    "GRU_bi", keep_prob, seed)
    #### Weighted Memory (S x d x N)
    M_w = tf.multiply(tf.tile(tf.expand_dims(beta,1),[1,d,1]), E)
    
    ################# Sentence-Level Content Attention Module #################
    ## Scores of Words (S x N)
    v_a_matrix = tf.tile(tf.expand_dims(v_a,2), [1,1,N])
    v_s_matrix = tf.tile(tf.expand_dims(v_s,2), [1,1,N])
    C = tf.where(mask_sentence[:,0,:], 
                 tf.reshape(matrix_tensor_product(weights["W_3"], 
                                                  tf.nn.tanh(tf.add(tf.add_n([matrix_tensor_product(weights["W_4"], tf.nn.dropout(M_w, keep_prob,seed=seed)), 
                                                                              matrix_tensor_product(weights["W_5"], tf.nn.dropout(v_a_matrix,keep_prob,seed=seed)), 
                                                                              matrix_tensor_product(weights["W_6"], tf.nn.dropout(v_s_matrix,keep_prob,seed=seed))]), 
                                                                    tf.nn.dropout(weights["b_3"], keep_prob, seed=seed)))), 
                            [S,N]), 
                -1e10*tf.ones([S,N]))    
    ## Attention Weights (S x N)
    A = tf.nn.softmax(C)
    ## Weighted embedding vector (S x d x 1)
    v_we = tensor_tensor_product(E, A)

    ########################## Classification Module ##########################
    ## Classification output vector (S x d x 1)
    v_aw = tf.nn.dropout(tf.nn.tanh(tf.add(tf.add(matrix_tensor_product(weights["W_7"], tf.nn.dropout(tf.reshape(v_s,[S,d,1]),keep_prob,seed=seed)), 
                                                  matrix_tensor_product(weights["W_8"], tf.nn.dropout(tf.reshape(v_we,[S,d,1]),keep_prob,seed=seed))), 
                                           weights["b_4"])),
                         keep_prob, seed=seed)
    v_sw = tf.nn.dropout(tf.nn.tanh(tf.add(tf.add(matrix_tensor_product(weights["W_9"], tf.nn.dropout(tf.reshape(v_a,[S,d,1]),keep_prob,seed=seed)), 
                                                  matrix_tensor_product(weights["W_10"],tf.nn.dropout(tf.reshape(v_we,[S,d,1]),keep_prob,seed=seed))), 
                                           weights["b_5"])), 
                         keep_prob, seed=seed)

    v_o = tf.nn.dropout(tf.nn.tanh(tf.add(tf.add_n([matrix_tensor_product(weights["W_11"], v_aw), 
                                                    matrix_tensor_product(weights["W_12"], v_sw)]), 
                                          weights["b_6"])), 
                        keep_prob, seed=seed)
    
    ## Linear Layer (S x nr_cat)
    v_L = tf.reshape(tf.add(matrix_tensor_product(weights["W_13"], v_o), weights["b_7"]), [-1,nr_cat])
    
    ############################ Loss Function ( x 1) ########################
   # loss_l2 = tf.add_n([tf.nn.l2_loss(v) for v in tf.trainable_variables()
   #                 if 'b' not in v.name])
    cost = tf.nn.softmax_cross_entropy_with_logits_v2(logits = v_L, labels = Y) #+ 0.01*loss_l2
    return cost, tf.nn.softmax(v_L)