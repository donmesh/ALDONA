import tensorflow as tf
import numpy as np
import pandas as pd
import datetime
from Data_Neural import data
from Baseline_Models import BaseA, BaseB, BaseC, CTX_models
from Neural_Attention_Model import DBGRU

def optimize(test, use_validation, model, epochs, batch_size, learning_rate, keep_probability, seed, mean, stddev, m, k, q, print_batches, print_results, save_results_to_file):
    path_data="../Data/Numpy/"
    path_results="../Results/"
    if use_validation:
        validation = "Validation_"
    else:
        validation = ""
    if test:
        if model == "ALDONA":
            E_LS_test, E_RS_test, E_test, v_a_test, v_s_test, masks_test, Y_test = data("Ontology_Remain_"+validation+"Test")
            ontology_predicted = np.load(path_data+"Ontology_"+validation+"Test_polarity_prediction_vector.npy")
            Y_ALDONA = np.load(path_data+"ALDONA_"+validation+"Test_polarity_vector.npy")
        else:
            E_LS_test, E_RS_test, E_test, v_a_test, v_s_test, masks_test, Y_test = data(validation+"Test")
        E_LS_train, E_RS_train, E_train, v_a_train, v_s_train, masks_train, Y_train = data(validation+"Train")
        accuracy_vector_test = np.zeros([epochs,1])
        loss_vector_test = np.zeros([epochs,1])
    else: 
        E_LS_train, E_RS_train, E_train, v_a_train, v_s_train, masks_train, Y_train = data("Train")
    S,d,N = E_train.shape
    nr_cat = Y_train.shape[1]
    
    with tf.Graph().as_default():
        tf.set_random_seed(seed)
        E_LS = tf.placeholder(tf.float32, [None, d, N], "E_LS")
        E_RS = tf.placeholder(tf.float32, [None, d, N], "E_RS")
        E = tf.placeholder(tf.float32, [None, d, N], "E")
        v_a = tf.placeholder(tf.float32, [None, d], "v_a")
        v_s = tf.placeholder(tf.float32, [None, d], "v_s")
        mask_left = tf.placeholder(tf.bool, [None, d, N], "mask_left")
        mask_right = tf.placeholder(tf.bool, [None, d, N], "mask_right")
        mask_aspect = tf.placeholder(tf.bool, [None, d, N], "mask_aspect")
        mask_left_with_aspect = tf.placeholder(tf.bool, [None, d, N], "mask_left_with_aspect")
        mask_right_with_aspect = tf.placeholder(tf.bool, [None, d, N], "mask_right_with_aspect")
        mask_sentence = tf.placeholder(tf.bool, [None, d, N], "mask_sentence")
        Y = tf.placeholder(tf.float32, [None, nr_cat], "Y")
        keep_prob = tf.placeholder(tf.float32, None, "keep_prob")
        
        weights = {
                ### Bidirectional Context Attention Mechanism
                    ## Bidirectional part (Eq. 3.8)
                    "W_fw_L" : tf.get_variable(initializer=tf.random_normal([d,d], mean=mean,stddev=stddev,seed=seed),dtype=tf.float32,name="W_fw_L"),
                    "W_bw_L" : tf.get_variable(initializer=tf.random_normal([d,d], mean=mean,stddev=stddev,seed=seed),dtype=tf.float32,name="W_bw_L"),
                    "b_bi_L" : tf.get_variable(initializer=tf.zeros([d,1]),dtype=tf.float32,name="b_bi_L"),
                    "W_fw_R" : tf.get_variable(initializer=tf.random_normal([d,d], mean=mean,stddev=stddev,seed=seed),dtype=tf.float32,name="W_fw_R"),
                    "W_bw_R" : tf.get_variable(initializer=tf.random_normal([d,d], mean=mean,stddev=stddev,seed=seed),dtype=tf.float32,name="W_bw_R"),
                    "b_bi_R" : tf.get_variable(initializer=tf.zeros([d,1]),dtype=tf.float32,name="b_bi_R"),
                    ## Attention weights beta (Eq. 3.12)
                    "W_1" : tf.get_variable(initializer=tf.random_normal([1,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32,name="W_1"),
                    "b_1" : tf.get_variable(initializer=tf.zeros([1,1]), dtype=tf.float32,name="b_1"),
                    "b_l" : tf.get_variable(initializer=0.5, trainable=False, dtype=tf.float32, name="b_l"),
                    "W_2" : tf.get_variable(initializer=tf.random_normal([1,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32,name="W_2"),
                    "b_2" : tf.get_variable(initializer=tf.zeros([1,1]), dtype=tf.float32,name="b_2"),
                    "b_r" : tf.get_variable(initializer=0.5, trainable=False, dtype=tf.float32, name="b_r"),
                ### Scores c (Eq. 3.15)
                    "W_3" : tf.get_variable(initializer=tf.random_normal([1,m], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_3"),
                    "W_4" : tf.get_variable(initializer=tf.random_normal([m,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_4"),
                    "W_5" : tf.get_variable(initializer=tf.random_normal([m,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_5"),
                    "W_6" : tf.get_variable(initializer=tf.random_normal([m,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_6"),
                    "b_3" : tf.get_variable(initializer=tf.zeros([m,1]), dtype=tf.float32, name="b_3"),
                ###  Classification Module (Eq. 3.18)
                    "W_7" : tf.get_variable(initializer=tf.random_normal([q,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_7"),
                    "W_8" : tf.get_variable(initializer=tf.random_normal([q,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_8"),
                    "b_4" : tf.get_variable(initializer=tf.zeros([q,1]), dtype=tf.float32, name="b_4"),
                    "W_9" : tf.get_variable(initializer=tf.random_normal([q,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_9"),
                    "W_10" : tf.get_variable(initializer=tf.random_normal([q,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_10"),
                    "b_5" : tf.get_variable(initializer=tf.zeros([q,1]), dtype=tf.float32, name="b_5"),
                    "W_11" : tf.get_variable(initializer=tf.random_normal([k,q], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_11"),
                    "W_12" : tf.get_variable(initializer=tf.random_normal([k,q], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_12"),
                    "b_6" : tf.get_variable(initializer=tf.zeros([k,1]), dtype=tf.float32, name="b_6"),
                   ### Linear Layer (Eq. 3.19)
                    "W_13" : tf.get_variable(initializer=tf.zeros([nr_cat,k]), dtype=tf.float32, name="W_13"),
                    "b_7" : tf.get_variable(initializer=tf.zeros([nr_cat,1]), dtype=tf.float32, name="b_7"),
                   
                   ################## Baseline Models
                   ### BaseA
                    "W_A1" : tf.get_variable(initializer=tf.random_normal([1,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_A1"),
                    "W_A2" : tf.get_variable(initializer=tf.random_normal([d,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_A2"),
                    "W_A3" : tf.get_variable(initializer=tf.random_normal([d,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_A3"),
                    "b_A1" : tf.get_variable(initializer=tf.zeros([d,1]), dtype=tf.float32, name="b_A1"),
                     ### MLP
                    "W_14" : tf.get_variable(initializer=tf.random_normal([d,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_14"),
                    "b_8" : tf.get_variable(initializer=tf.zeros([d,1]), dtype=tf.float32, name="b_8"),
                    ### Linear Layer
                    "W_15" : tf.get_variable(initializer=tf.random_normal([nr_cat,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_15"),
                    "b_9" : tf.get_variable(initializer=tf.zeros([nr_cat,1]), dtype=tf.float32, name="b_9"),
                   ### Common Baseline Weights
                    "W_16" : tf.get_variable(initializer=tf.random_normal([1,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_16"),
                    "W_17" : tf.get_variable(initializer=tf.random_normal([d,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_17"),
                    "W_18" : tf.get_variable(initializer=tf.random_normal([d,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_18"),
                    "W_19" : tf.get_variable(initializer=tf.random_normal([d,d], mean=mean, stddev=stddev, seed=seed), dtype=tf.float32, name="W_19"),
                    "b_10" : tf.get_variable(initializer=tf.zeros([d,1]), dtype=tf.float32, name="b_10")}

        if model == "BaseA":
            cost, v_L = BaseA(E, v_a, v_s, mask_sentence, Y, weights, keep_prob, seed)
        elif model == "BaseB":
            cost, v_L = BaseB(E, v_a, v_s, mask_sentence, Y, weights, keep_prob, seed)
        elif model == "BaseC":
            cost, v_L = BaseC(E, v_a, v_s, mask_left, mask_right, mask_sentence, mask_left_with_aspect, mask_right_with_aspect, Y, weights, keep_prob, seed)
        elif model == "CABASC":
            cost, v_L = CTX_models("GRU_uni", E, E_LS, E_RS, v_a, v_s, mask_left, mask_aspect, mask_right, mask_sentence, mask_left_with_aspect, mask_right_with_aspect, Y, weights, keep_prob, seed)
        elif model == "CTX-LSTM":
            cost, v_L = CTX_models("LSTM_uni", E, E_LS, E_RS, v_a, v_s, mask_left, mask_aspect, mask_right, mask_sentence, mask_left_with_aspect, mask_right_with_aspect, Y, weights, keep_prob, seed)
        elif model == "CTX-BGRU":
            cost, v_L = CTX_models("GRU_bi", E, E_LS, E_RS, v_a, v_s, mask_left, mask_aspect, mask_right, mask_sentence, mask_left_with_aspect, mask_right_with_aspect, Y, weights, keep_prob, seed)
        elif model == "CTX-BLSTM":
            cost, v_L = CTX_models("LSTM_bi", E, E_LS, E_RS, v_a, v_s, mask_left, mask_aspect, mask_right, mask_sentence, mask_left_with_aspect, mask_right_with_aspect, Y, weights, keep_prob, seed)
        elif model == "DBGRU" or model == "ALDONA":
            cost, v_L = DBGRU(E, E_LS, E_RS, v_a, v_s, mask_left, mask_aspect, mask_right, mask_sentence, mask_left_with_aspect, mask_right_with_aspect, Y, weights, keep_prob, seed)
        else: 
            raise ValueError("Allowed models are:\nBaseA\nBaseB\nBaseC\nCABASC\nCTX-LSTM\nCTX-BGRU\nCTX-BLSTM\nDBGRU\nALDONA") 
        
        train = tf.train.GradientDescentOptimizer(learning_rate).minimize(cost)
        
        with tf.Session() as session:
            session.run(tf.global_variables_initializer())
            if batch_size>S: 
                print("Batch size is set to the number of sentences: {}".format(S))
                batch_size=S
            nr_batches = int(np.ceil(S/batch_size))
            accuracy_vector_train = np.zeros([epochs,1])
            loss_vector_train = np.zeros([epochs,1])  
            time = np.zeros([epochs,1], object)
            
            for epoch in np.arange(epochs):
                loss_train = 0
                prediction_train = np.zeros([S,nr_cat])
                if test:
                    loss_test, pred_test = session.run([cost,v_L], feed_dict = {E : E_test,
                                                                                E_LS : E_LS_test,
                                                                                E_RS : E_RS_test,
                                                                                v_a : v_a_test,
                                                                                v_s : v_s_test,
                                                                                mask_left : masks_test["left"],
                                                                                mask_aspect : masks_test["aspect"],
                                                                                mask_right : masks_test["right"],
                                                                                mask_left_with_aspect : masks_test["left_with_aspect"],
                                                                                mask_right_with_aspect : masks_test["right_with_aspect"],
                                                                                mask_sentence: masks_test["sentence"],
                                                                                Y : Y_test,
                                                                                keep_prob : 1.0})
                    loss_test = loss_test.mean() 
                    if model == "ALDONA":
                        prediction_test = np.concatenate([ontology_predicted, pred_test])
                        accuracy_test = 100*np.mean(np.equal(np.argmax(prediction_test,1), np.argmax(Y_ALDONA, 1)))
                    else:
                        prediction_test = pred_test
                        accuracy_test = 100*np.mean(np.equal(np.argmax(prediction_test,1), np.argmax(Y_test,1)))
                start_epoch = datetime.datetime.now()
                for batch in np.arange(nr_batches):
                    start_batch = datetime.datetime.now()
                    down = batch_size * batch
                    up = (batch+1)*batch_size if (batch+1)*batch_size<=S else S-(1-batch)*batch_size
                    loss_batch, pred_train, _ = session.run([cost,v_L,train], feed_dict = {E : E_train[down:up,:,:],
                                                                                           E_LS : E_LS_train[down:up,:,:],
                                                                                           E_RS : E_RS_train[down:up,:,:],
                                                                                           v_a : v_a_train[down:up,:],
                                                                                           v_s : v_s_train[down:up,:],
                                                                                           mask_left : masks_train["left"][down:up,:,:],
                                                                                           mask_aspect : masks_train["aspect"][down:up,:,:],
                                                                                           mask_right : masks_train["right"][down:up,:,:],
                                                                                           mask_left_with_aspect : masks_train["left_with_aspect"][down:up,:,:],
                                                                                           mask_right_with_aspect : masks_train["right_with_aspect"][down:up,:,:],
                                                                                           mask_sentence: masks_train["sentence"][down:up,:,:],
                                                                                           Y : Y_train[down:up,:],
                                                                                           keep_prob : keep_probability})
                    loss_train += loss_batch.mean()
                    prediction_train[down:up,:] = pred_train
                    if print_batches:
                        end_batch = datetime.datetime.now()
                        train_accuracy_batch = 100*np.mean(np.equal(np.argmax(pred_train,1), np.argmax(Y_train[down:up],1)))
                        print("Epoch",epoch,"Batch",batch,"Train loss",loss_batch.mean(),"Train accuracy", train_accuracy_batch,"Time",end_batch-start_batch)
                loss_train = loss_train/nr_batches
                accuracy_train = 100*np.mean(np.equal(np.argmax(prediction_train,1), np.argmax(Y_train,1)))
                
                if print_results and test:
                    time_epoch = datetime.datetime.now() - start_epoch
                    print("Epoch",epoch,"Train loss",loss_train,"Test loss",loss_test,"Train accuracy",accuracy_train,"Test accuracy",accuracy_test,"Time",time_epoch)
                elif print_results and not test:
                    time_epoch = datetime.datetime.now() -start_epoch
                    print("Epoch",epoch,"Train loss",loss_train,"Train accuracy",accuracy_train,"Time",time_epoch)
                
                if save_results_to_file and test:
                    time[epoch] = time_epoch
                    loss_vector_train[epoch] = loss_train
                    loss_vector_test[epoch] = loss_test   
                    accuracy_vector_train[epoch] = accuracy_train
                    accuracy_vector_test[epoch] = accuracy_test
                elif save_results_to_file and not test:
                    time[epoch] = time_epoch
                    loss_vector_train[epoch] = loss_train
                    accuracy_vector_train[epoch] = accuracy_train
                    
            if save_results_to_file and test:
                results = np.concatenate([np.arange(epochs).reshape([-1,1]), loss_vector_train, loss_vector_test, accuracy_vector_train, accuracy_vector_test, time],1)
                results_df = pd.DataFrame(data=results, columns=["Epoch","Train loss", "Test loss", "Train accuracy", "Test accuracy", "Time"])
                results_df.to_csv(path_results+model+"_"+validation+"Results.csv", index=False)
            
            if save_results_to_file and not test:
                results = np.concatenate([np.arange(epochs).reshape([-1,1]), loss_vector_train, accuracy_vector_train, time],1)
                results_df = pd.DataFrame(data=results, columns=["Epoch", "Train loss", "Train accuracy", "Time"])
                results_df.to_csv(path_results+model+"_"+validation+"Train_Results.csv", index=False)       