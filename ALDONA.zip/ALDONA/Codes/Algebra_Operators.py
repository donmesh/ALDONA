import tensorflow as tf

def matrix_tensor_product(matrix, tensor):
    return tf.transpose(tf.tensordot(matrix, tensor, axes = [[1], [1]]),[1,0,2])    

def tensor_tensor_product(A, B):
    return tf.matmul(A, tf.transpose(tf.expand_dims(B,1), [0,2,1]))