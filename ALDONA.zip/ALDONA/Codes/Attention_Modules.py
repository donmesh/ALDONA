import tensorflow as tf
from Algebra_Operators import matrix_tensor_product

def position_attention_module(E, mask_left, mask_right, mask_left_with_aspect, mask_right_with_aspect, mask_sentence):
    S = tf.shape(E)[0]
    d = tf.shape(E)[1]
    N = tf.shape(E)[2]
    ## left_masked (S x N)
    left_tiled = tf.tile(tf.reshape(tf.range(N+1,1,-1), [1,-1]), [S,1]) - tf.reshape(tf.reduce_sum(tf.cast(mask_right_with_aspect[:,0,:], tf.int32), 1), [-1,1])
    left_reversed = left_tiled - (N+1 - tf.reshape(tf.reduce_sum(tf.cast(mask_sentence[:,0,:], tf.int32), 1), [-1,1]))
    left_masked = tf.where(mask_left[:,0,:], tf.cast(left_reversed, tf.float32), tf.zeros([S,N]))   
    ## right_masked (S x N)
    right_tiled = tf.tile(tf.reshape(tf.range(1,N+1), [1,-1]), [S,1]) - tf.reshape(tf.reduce_sum(tf.cast(mask_left_with_aspect[:,0,:], tf.int32), 1), [-1,1])
    right_masked = tf.where(mask_right[:,0,:], tf.cast(right_tiled,tf.float32), tf.zeros([S,N]))
    ## sentence_masked (S x N)
    sentence_locations = tf.divide(tf.add(left_masked, right_masked), tf.cast(tf.reshape(tf.reduce_sum(tf.cast(mask_sentence[:,0,:] ,tf.int32),1), [-1,1]), tf.float32))
    sentence_masked = tf.where(mask_sentence[:,0,:], 1-sentence_locations, tf.zeros([S,N]))
    ## Lambda (S x d x N)
    Lambda = tf.tile(tf.expand_dims(sentence_masked,1), [1,d,1])
    return Lambda

def context_attention_module(E_LS, E_RS, weights, mask_left, mask_aspect, mask_right, mask_left_with_aspect, mask_right_with_aspect, mask_sentence, module, keep_prob, seed):
    left_length = tf.reduce_sum(tf.cast(mask_left_with_aspect[:,0,:] ,tf.int32),1)
    right_length = tf.reduce_sum(tf.cast(mask_right_with_aspect[:,0,:] ,tf.int32),1)
    sentence_length = tf.reduce_sum(tf.cast(mask_sentence[:,0,:] ,tf.int32),1)
    E_LS_r = tf.reverse_sequence(E_LS, left_length, seq_axis=2, batch_axis=0)
    E_RS_r = tf.reverse_sequence(tf.reverse_sequence(E_RS, sentence_length, seq_axis=2, batch_axis=0), right_length, seq_axis=2,batch_axis=0)
    
    S = tf.shape(E_LS)[0]
    d = E_LS.get_shape()[1]
    N = tf.shape(E_LS)[2]
    
    def GRU_uni(E_LS_r, E_RS_r, d, N, left_length, right_length, keep_prob):
        with tf.variable_scope("Left_GRU_uni", reuse=tf.AUTO_REUSE) as Left_GRU_uni:
            cell_left = tf.nn.rnn_cell.GRUCell(d)
            cell_left = tf.nn.rnn_cell.DropoutWrapper(cell_left, output_keep_prob=keep_prob, input_keep_prob=keep_prob,
                                                 state_keep_prob=keep_prob, seed=seed, dtype=tf.float32)
            output_left, _ = tf.nn.dynamic_rnn(cell_left, tf.transpose(E_LS_r,[0,2,1]), sequence_length=left_length, dtype=tf.float32, scope= Left_GRU_uni)
            H_left = tf.transpose(output_left, [0,2,1])    
        with tf.variable_scope("Right_GRU_uni", reuse=tf.AUTO_REUSE) as Right_GRU_uni:
            cell_right = tf.nn.rnn_cell.GRUCell(d)
            cell_right = tf.nn.rnn_cell.DropoutWrapper(cell_right, output_keep_prob=keep_prob, input_keep_prob=keep_prob,
                                                 state_keep_prob=keep_prob, seed=seed, dtype=tf.float32)
            output_right, _ = tf.nn.dynamic_rnn(cell_right, tf.transpose(E_RS_r,[0,2,1]), sequence_length=right_length, dtype=tf.float32, scope= Right_GRU_uni)
            H_right = tf.transpose(output_right, [0,2,1])
        return H_left, H_right
    
    def LSTM_uni(E_LS_r, E_RS_r, d, N, left_length, right_length, keep_prob):
        with tf.variable_scope("Left_LSTM_uni", reuse=tf.AUTO_REUSE) as Left_LSTM_uni:
            cell_left = tf.nn.rnn_cell.LSTMCell(d)
            cell_left = tf.nn.rnn_cell.DropoutWrapper(cell_left, output_keep_prob=keep_prob, input_keep_prob=keep_prob,
                                                 state_keep_prob=keep_prob, seed=seed, dtype=tf.float32)
            output_left, _ = tf.nn.dynamic_rnn(cell_left, tf.transpose(E_LS_r,[0,2,1]), sequence_length=left_length, dtype=tf.float32, scope= Left_LSTM_uni)
            H_left = tf.transpose(output_left, [0,2,1])   
        with tf.variable_scope("Right_LSTM_uni", reuse=tf.AUTO_REUSE) as Right_LSTM_uni:
            cell_right = tf.nn.rnn_cell.LSTMCell(d)
            cell_right = tf.nn.rnn_cell.DropoutWrapper(cell_right, output_keep_prob=keep_prob, input_keep_prob=keep_prob,
                                                 state_keep_prob=keep_prob, seed=seed, dtype=tf.float32)
            output_right, _ = tf.nn.dynamic_rnn(cell_right, tf.transpose(E_RS_r,[0,2,1]), sequence_length=right_length, dtype=tf.float32, scope= Right_LSTM_uni)
            H_right = tf.transpose(output_right, [0,2,1])
        return H_left, H_right
    
    def GRU_bi(E_LS_r, E_RS_r, weights, d, N, left_length, right_length, keep_prob):
        with tf.variable_scope("Left_GRU_bi", reuse=tf.AUTO_REUSE) as Left_GRU_bi:
            cell_l = tf.nn.rnn_cell.GRUCell(d)
            cell_left = tf.nn.rnn_cell.DropoutWrapper(cell_l, output_keep_prob=keep_prob, input_keep_prob=keep_prob,
                                                 state_keep_prob=keep_prob, seed=seed, dtype=tf.float32)
            output_left, _ = tf.nn.bidirectional_dynamic_rnn(cell_left,cell_left, tf.transpose(E_LS_r,[0,2,1]), sequence_length=left_length, dtype=tf.float32, scope= Left_GRU_bi)
            H_left_fw_T, H_left_bw_T = output_left
            H_left_fw = tf.transpose(H_left_fw_T, [0,2,1])
            H_left_bw = tf.transpose(H_left_bw_T, [0,2,1])
            H_left = tf.nn.tanh(tf.add(tf.add_n([matrix_tensor_product(weights["W_fw_L"], H_left_fw), 
                                                 matrix_tensor_product(weights["W_bw_L"], H_left_bw)]), 
                                       weights["b_bi_L"]))            
        with tf.variable_scope("Right_GRU_bi", reuse=tf.AUTO_REUSE) as Right_GRU_bi:
            cell_r = tf.nn.rnn_cell.GRUCell(d)
            cell_right = tf.nn.rnn_cell.DropoutWrapper(cell_r, output_keep_prob=keep_prob, input_keep_prob=keep_prob,
                                                 state_keep_prob=keep_prob, seed=seed, dtype=tf.float32)
            output_right, _ = tf.nn.bidirectional_dynamic_rnn(cell_right, cell_right, tf.transpose(E_RS_r,[0,2,1]), sequence_length=right_length, dtype=tf.float32, scope= Right_GRU_bi)
            H_right_fw_T, H_right_bw_T = output_right
            H_right_fw = tf.transpose(H_right_fw_T, [0,2,1])
            H_right_bw = tf.transpose(H_right_bw_T, [0,2,1])
            H_right = tf.nn.tanh(tf.add(tf.add_n([matrix_tensor_product(weights["W_fw_R"], H_right_fw),
                                                  matrix_tensor_product(weights["W_bw_R"], H_right_bw)]),
                                        weights["b_bi_R"]))
        return H_left, H_right
    
    def LSTM_bi(E_LS_r, E_RS_r, weights, d, N, left_length, right_length, keep_prob):
        with tf.variable_scope("Left_LSTM_bi", reuse=tf.AUTO_REUSE) as Left_LSTM_bi:
            cell_left = tf.nn.rnn_cell.LSTMCell(d)
            cell_left = tf.nn.rnn_cell.DropoutWrapper(cell_left, output_keep_prob=keep_prob, input_keep_prob=keep_prob,
                                                 state_keep_prob=keep_prob, seed=seed, dtype=tf.float32)
            output_left, _ = tf.nn.bidirectional_dynamic_rnn(cell_left,cell_left, tf.transpose(E_LS_r,[0,2,1]), sequence_length=left_length, dtype=tf.float32, scope= Left_LSTM_bi)
            H_left_fw_T, H_left_bw_T = output_left
            H_left_fw = tf.transpose(H_left_fw_T, [0,2,1])
            H_left_bw = tf.transpose(H_left_bw_T, [0,2,1])
            H_left = tf.nn.tanh(tf.add(tf.add_n([matrix_tensor_product(weights["W_fw_L"], H_left_fw), 
                                                 matrix_tensor_product(weights["W_bw_L"], H_left_bw)]), 
                                       weights["b_bi_L"]))  
        with tf.variable_scope("Right_LSTM_bi", reuse=tf.AUTO_REUSE) as Right_LSTM_bi:
            cell_right = tf.nn.rnn_cell.LSTMCell(d)
            cell_right = tf.nn.rnn_cell.DropoutWrapper(cell_right, output_keep_prob=keep_prob, input_keep_prob=keep_prob,
                                                 state_keep_prob=keep_prob, seed=seed, dtype=tf.float32)
            output_right, _ = tf.nn.bidirectional_dynamic_rnn(cell_right, cell_right, tf.transpose(E_RS_r,[0,2,1]), sequence_length=right_length, dtype=tf.float32, scope= Right_LSTM_bi)
            H_right_fw_T, H_right_bw_T = output_right
            H_right_fw = tf.transpose(H_right_fw_T, [0,2,1])
            H_right_bw = tf.transpose(H_right_bw_T, [0,2,1])
            H_right = tf.nn.tanh(tf.add(tf.add_n([matrix_tensor_product(weights["W_fw_R"], H_right_fw),
                                                  matrix_tensor_product(weights["W_bw_R"], H_right_bw)]),
                                        weights["b_bi_R"]))
        return H_left, H_right
    if module == "GRU_uni":
        H_LS_raw, H_RS_raw = GRU_uni(E_LS_r, E_RS_r, d, N, left_length, right_length, keep_prob) 
    if module == "LSTM_uni":
        H_LS_raw, H_RS_raw = LSTM_uni(E_LS_r, E_RS_r, d, N, left_length, right_length, keep_prob) 
    if module == "GRU_bi":
        H_LS_raw, H_RS_raw = GRU_bi(E_LS_r, E_RS_r, weights, d, N, left_length, right_length, keep_prob)
    if module == "LSTM_bi":
        H_LS_raw, H_RS_raw = LSTM_bi(E_LS_r, E_RS_r, weights, d, N, left_length, right_length, keep_prob)
        
    H_LS_masked = tf.where(mask_left_with_aspect, 
                           tf.reverse_sequence(H_LS_raw, left_length, seq_axis=2, batch_axis=0), 
                           tf.zeros([S,d,N]))        
    H_RS_masked = tf.where(mask_right_with_aspect, 
                           tf.reverse_sequence(tf.reverse_sequence(H_RS_raw, right_length, seq_axis=2, batch_axis=0), 
                                               sentence_length, seq_axis=2, batch_axis=0), 
                           tf.zeros([S,d,N]))
    beta = MLP_beta(H_LS_masked, H_RS_masked, weights, mask_left, mask_aspect, mask_right, mask_left_with_aspect, mask_right_with_aspect)   
    return beta


def MLP_beta(H_LS, H_RS, weights, mask_left, mask_aspect, mask_right, mask_left_with_aspect, mask_right_with_aspect):
    S = tf.shape(H_LS)[0]
    N = tf.shape(H_LS)[2]

    left = tf.reshape(mask_left[:,0,:], [S,1,N])
    aspect = tf.reshape(mask_aspect[:,0,:], [S,1,N])
    right = tf.reshape(mask_right[:,0,:], [S,1,N])
    left_with_aspect = tf.reshape(mask_left_with_aspect[:,0,:], [S,1,N])
    right_with_aspect = tf.reshape(mask_right_with_aspect[:,0,:], [S,1,N])
    
    beta_LS = tf.add(tf.nn.sigmoid(tf.where(left_with_aspect, 
                                            tf.add(matrix_tensor_product(weights["W_1"], H_LS), 
                                                   weights["b_1"]), 
                                            -1e10*tf.ones([S,1,N]))), 
                    weights["b_l"])
    beta_RS = tf.add(tf.nn.sigmoid(tf.where(right_with_aspect, 
                                            tf.add(matrix_tensor_product(weights["W_2"], H_RS),
                                                   weights["b_2"]), 
                                            -1e10*tf.ones([S,1,N]))), 
                    weights["b_r"])
    beta_LC = tf.where(left, beta_LS, tf.zeros([S,1,N]))
    beta_A  = tf.where(aspect, 
                       tf.div(tf.add(tf.where(aspect, beta_LS, tf.zeros([S,1,N])), 
                                     tf.where(aspect, beta_RS, tf.zeros([S,1,N]))),
                              2),
                       tf.zeros([S,1,N]))
    beta_RC = tf.where(right, beta_RS, tf.zeros([S,1,N]))
    beta = beta_LC + beta_A + beta_RC
    return tf.reshape(beta, [S,N])