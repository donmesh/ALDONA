import owlready2 as OWL
import numpy as np
import tensorflow as tf
from Ontology_Reader import get_majority_class, classes_into_types, predict_sentiment
from Visualization import ontology_results
from Algebra_Operators import matrix_tensor_product, tensor_tensor_product
from Attention_Modules import position_attention_module, context_attention_module

def Ont(purpose, use_validation, print_results, save_results_to_file):
    path_data="../Data/Numpy/"
    path_ontology="../Ontology/"
    if use_validation:
        validation = "Validation_"
    else:
        validation = ""
    
    polarity_vector_train = np.load(path_data+validation+"Train_polarity_vector.npy")
    sentence_vector_test = np.load(path_data+validation+purpose+"_sentence_vector.npy")
    target_vector_test = np.load(path_data+validation+purpose+"_target_vector.npy")

    ontology = OWL.get_ontology(path_ontology+"ontology.owl")
    ontology.base_iri = path_ontology+"ontology.owl"
    ontology = ontology.load()
    classes = set(ontology.classes())
    my_dict = {}
    for onto_class in classes:
        my_dict[onto_class] = onto_class.lex
    
    majority = get_majority_class(polarity_vector_train)
    types = classes_into_types(classes)
    
    ontology_prediction_vector = np.zeros([target_vector_test.shape[0],3])
    for i in range(len(sentence_vector_test)):
        pred, _, _ = predict_sentiment(sentence_vector_test[i], 
                                       target_vector_test[i], 
                                       ontology, False, majority, 
                                       types, my_dict)
        ontology_prediction_vector[i,:] = pred
    
    np.save(path_data+"Ontology_Results_"+validation+purpose+".npy", ontology_prediction_vector)

    ontology_results(purpose=purpose,
                     use_validation=use_validation, 
                     print_results=print_results,
                     save_results_to_file=save_results_to_file)

def BaseA(E, v_a, v_s, mask_sentence, Y, weights, keep_prob, seed):
    S = tf.shape(E)[0]
    N = tf.shape(E)[2]
    nr_cat = tf.shape(Y)[1]
    ######################## Content Attention Module #########################
    ## Scores of Words (S x N)
    v_a_matrix = tf.tile(tf.expand_dims(v_a,2), [1,1,N])
    C = tf.where(mask_sentence[:,0,:], 
                 tf.reshape(matrix_tensor_product(weights["W_A1"], tf.nn.tanh(tf.add(tf.add_n([matrix_tensor_product(weights["W_A2"], E), 
                                                                                              matrix_tensor_product(weights["W_A3"], v_a_matrix)]), 
                                                                                    weights["b_A1"]))), 
                            [S,N]), 
                 -1e10*tf.ones([S,N]))
    ## Attention Weights for Scores (S x N) 
    A = tf.nn.dropout(tf.nn.softmax(C), keep_prob, seed=seed)
    ## Sentence Representation (S x d x 1)
    v_ns = tensor_tensor_product(E, A)
    
    #################### Multilayer Perceptron (S x d x 1) ####################
    v_ms = tf.nn.dropout(tf.nn.tanh(tf.add(matrix_tensor_product(weights["W_14"],v_ns), weights["b_8"])), keep_prob, seed=seed)
    
    ##################### Linear Layer (S x nr_cat) ##########################
    v_L = tf.reshape(tf.add(matrix_tensor_product(weights["W_15"], v_ms), weights["b_9"]), [-1,nr_cat])
    
    ######################### Loss Function (1 x 1) ###########################
    cost = tf.nn.softmax_cross_entropy_with_logits_v2(logits = v_L, labels = Y)
    return cost, tf.nn.softmax(v_L)

def BaseB(E, v_a, v_s, mask_sentence, Y, weights, keep_prob, seed):
    S = tf.shape(E)[0]
    d = tf.shape(E)[1]
    N = tf.shape(E)[2]
    nr_cat = tf.shape(Y)[1]
    ################ Sentence-Level Content Attention Module ##################
    ## Scores of Words (S x N)
    v_a_matrix = tf.tile(tf.expand_dims(v_a,2), [1,1,N])
    v_s_matrix = tf.tile(tf.expand_dims(v_s,2), [1,1,N])
    C = tf.where(mask_sentence[:,0,:], 
                 tf.reshape(matrix_tensor_product(weights["W_16"], tf.nn.tanh(tf.add(tf.add_n([matrix_tensor_product(weights["W_17"], E), 
                                                                                              matrix_tensor_product(weights["W_18"], v_a_matrix), 
                                                                                              matrix_tensor_product(weights["W_19"], v_s_matrix)]), 
                                                                                    weights["b_10"]))), 
                            [S,N]), 
                 -1e10*tf.ones([S,N]))
    ## Attention Weights for Scores (S x N) 
    A = tf.nn.dropout(tf.nn.softmax(C), keep_prob, seed=seed)
    ## Sentence Representation (S x d x 1)
    v_ts = tensor_tensor_product(E, A)
    v_ns = tf.add(v_ts, tf.reshape(v_s,[S,d,1]))
    
    #################### Multilayer Perceptron (S x d x 1) ####################
    v_ms = tf.nn.dropout(tf.nn.tanh(tf.add(matrix_tensor_product(weights["W_14"],v_ns), weights["b_8"])), keep_prob, seed=seed)
    
    ##################### Linear Layer (S x nr_cat) ##########################
    v_L = tf.reshape(tf.add(matrix_tensor_product(weights["W_15"], v_ms), weights["b_9"]), [-1,nr_cat])
    
    ######################### Loss Function (1 x 1) ###########################
    cost = tf.nn.softmax_cross_entropy_with_logits_v2(logits = v_L, labels = Y)
    return cost, tf.nn.softmax(v_L)

def BaseC(E, v_a, v_s, mask_left, mask_right, mask_sentence, mask_left_with_aspect, mask_right_with_aspect, Y, weights, keep_prob, seed):
    S = tf.shape(E)[0]
    d = tf.shape(E)[1]
    N = tf.shape(E)[2] 
    nr_cat = tf.shape(Y)[1]
    ############## Position Attention Weighted Memory (S x d x N) #############
    Lambda = position_attention_module(E, mask_left, mask_right, 
                                                mask_left_with_aspect, 
                                                mask_right_with_aspect, 
                                                mask_sentence)
    M_w = tf.multiply(Lambda, E)
    ################ Sentence-Level Content Attention Module ##################
    ## Scores of Words (S x N)
    v_a_matrix = tf.tile(tf.expand_dims(v_a,2), [1,1,N])
    v_s_matrix = tf.tile(tf.expand_dims(v_s,2), [1,1,N])
    C = tf.where(mask_sentence[:,0,:], 
                 tf.reshape(matrix_tensor_product(weights["W_16"], tf.nn.tanh(tf.add(tf.add_n([matrix_tensor_product(weights["W_17"], M_w), 
                                                                                              matrix_tensor_product(weights["W_18"], v_a_matrix), 
                                                                                              matrix_tensor_product(weights["W_19"], v_s_matrix)]), 
                                                                                    weights["b_10"]))), 
                            [S,N]), 
                 -1e10*tf.ones([S,N]))
    ## Attention Weights for Scores (S x N) 
    A = tf.nn.dropout(tf.nn.softmax(C), keep_prob, seed=seed)
    ## Sentence Representation (S x d x 1)
    v_ts = tensor_tensor_product(E, A)
    v_ns = tf.add(v_ts, tf.reshape(v_s,[S,d,1]))
    
    #################### Multilayer Perceptron (S x d x 1) ####################
    v_ms = tf.nn.dropout(tf.nn.tanh(tf.add(matrix_tensor_product(weights["W_14"],v_ns), weights["b_8"])), keep_prob, seed=seed)
    
    ##################### Linear Layer (S x nr_cat) ##########################
    v_L = tf.reshape(tf.add(matrix_tensor_product(weights["W_15"], v_ms), weights["b_9"]), [-1,nr_cat])
    
    ######################### Loss Function (1 x 1) ###########################
    cost = tf.nn.softmax_cross_entropy_with_logits_v2(logits = v_L, labels = Y)
    return cost, tf.nn.softmax(v_L)

################### CABASC, CTX-LSTM, CTX-BGRU, CTX-BLSTM #####################
def CTX_models(module, E, E_LS, E_RS, v_a, v_s, mask_left, mask_aspect, mask_right, mask_sentence, mask_left_with_aspect, mask_right_with_aspect, Y, weights, keep_prob, seed):
    S = tf.shape(E)[0]
    d = tf.shape(E)[1]
    N = tf.shape(E)[2]
    nr_cat = tf.shape(Y)[1]
    
    ############## Context Attention Weighted Memory (S x d x N) #############
    beta = context_attention_module(E_LS, E_RS, weights, mask_left, mask_aspect, 
                                    mask_right, mask_left_with_aspect, 
                                    mask_right_with_aspect, mask_sentence, 
                                    module, keep_prob, seed)
    M_w = tf.multiply(tf.tile(tf.expand_dims(beta,1),[1,d,1]), E)
    
    ################ Sentence-Level Content Attention Module ##################
    ## Scores of Words (S x N)
    v_a_matrix = tf.tile(tf.expand_dims(v_a,2), [1,1,N])
    v_s_matrix = tf.tile(tf.expand_dims(v_s,2), [1,1,N])
    C = tf.where(mask_sentence[:,0,:], 
                 tf.reshape(matrix_tensor_product(weights["W_16"], tf.nn.tanh(tf.add(tf.add_n([matrix_tensor_product(weights["W_17"], M_w), 
                                                                                              matrix_tensor_product(weights["W_18"], v_a_matrix), 
                                                                                              matrix_tensor_product(weights["W_19"], v_s_matrix)]), 
                                                                                    weights["b_10"]))), 
                            [S,N]), 
                 -1e10*tf.ones([S,N]))
    ## Attention Weights for Scores (S x N) 
    A = tf.nn.dropout(tf.nn.softmax(C), keep_prob, seed=seed)
    ## Sentence Representation (S x d x 1)
    v_ts = tensor_tensor_product(E, A)
    v_ns = tf.add(v_ts, tf.reshape(v_s,[S,d,1]))
    
    #################### Multilayer Perceptron (S x d x 1) ####################
    v_ms = tf.nn.dropout(tf.nn.tanh(tf.add(matrix_tensor_product(weights["W_14"],v_ns), weights["b_8"])), keep_prob, seed=seed)
    
    ##################### Linear Layer (S x nr_cat) ##########################
    v_L = tf.reshape(tf.add(matrix_tensor_product(weights["W_15"], v_ms), weights["b_9"]), [-1,nr_cat])
    
    ######################### Loss Function (1 x 1) ###########################
    cost = tf.nn.softmax_cross_entropy_with_logits_v2(logits = v_L, labels = Y)
    return cost, tf.nn.softmax(v_L)