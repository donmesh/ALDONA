import owlready2 as OWL
import numpy as np
from Ontology_Reader import get_majority_class, classes_into_types, predict_sentiment
from Optimization import optimize

def ALDONA(test, use_validation, epochs, batch_size, learning_rate, keep_probability, seed, mean, stddev, m, k, q, print_batches, print_results, save_results_to_file):    
    path_data="../Data/Numpy/"
    path_ontology="../Ontology/"
    deleted = 0
    ontology_prediction_vector = np.array([[0,0,0]])
    sentence_vector_remain, target_vector_remain, polarity_vector_remain = [],[],[]
    neural_index = []
    ontology_index = []
    my_dict = {}
       
    if use_validation:
        validation = "Validation_"
    else:
        validation = ""
    
    polarity_vector_train = np.load(path_data+validation+"Train_polarity_vector.npy")
    sentence_vector_test = np.load(path_data+validation+"Test_sentence_vector.npy")
    target_vector_test = np.load(path_data+validation+"Test_target_vector.npy")
    polarity_vector_test = np.load(path_data+validation+"Test_polarity_vector.npy")
    
    ontology = OWL.get_ontology(path_ontology+"ontology.owl")
    ontology.base_iri = path_ontology+"ontology.owl"
    ontology = ontology.load()
    classes = set(ontology.classes())
    for onto_class in classes:
        my_dict[onto_class] = onto_class.lex
    
    polarity_vector_check = polarity_vector_test
    majority = get_majority_class(polarity_vector_train)
    types = classes_into_types(classes)
    
    for i in range(len(sentence_vector_test)):
        pred, backup, _ = predict_sentiment(sentence_vector_test[i], 
                                                target_vector_test[i], 
                                                ontology, True, majority, 
                                                types, my_dict)
        if backup:
            sentence_vector_remain.append(sentence_vector_test[i])
            target_vector_remain.append(target_vector_test[i])
            polarity_vector_remain.append(polarity_vector_test[i])
            neural_index.append(i)
            polarity_vector_check = np.delete(polarity_vector_check, i - deleted, 0)
            deleted += 1
        else:
            ontology_index.append(i)
            ontology_prediction_vector = np.append(ontology_prediction_vector,pred,axis=0)
    ontology_prediction_vector = np.delete(ontology_prediction_vector, 0,0)

    left = np.load(path_data+validation+"Test_left_embedding_data.npy")
    aspect = np.load(path_data+validation+"Test_aspect_embedding_data.npy")
    right = np.load(path_data+validation+"Test_right_embedding_data.npy")
    polarity = np.load(path_data+validation+"Test_polarity_vector.npy")
    
    np.save(path_data+"Ontology_Remain_"+validation+"Test_left_embedding_data.npy", left[neural_index,:,:])
    np.save(path_data+"Ontology_Remain_"+validation+"Test_aspect_embedding_data.npy", aspect[neural_index,:,:])
    np.save(path_data+"Ontology_Remain_"+validation+"Test_right_embedding_data.npy", right[neural_index,:,:])
    np.save(path_data+"Ontology_Remain_"+validation+"Test_polarity_vector.npy", polarity[neural_index,:])
    
    polarity_ontology_test = polarity[ontology_index,:]
    polarity_neural_test = polarity[neural_index,:]
    polarity_final_test = np.concatenate([polarity_ontology_test, polarity_neural_test],0)
    
    np.save(path_data+"Ontology_"+validation+"Test_polarity_prediction_vector.npy", ontology_prediction_vector)
    np.save(path_data+"ALDONA_"+validation+"Test_polarity_vector.npy", polarity_final_test)
    
    optimize(test=test, 
             use_validation=use_validation,
             model="ALDONA",
             epochs=epochs,
             batch_size=batch_size,
             learning_rate=learning_rate,
             keep_probability=keep_probability,
             seed=seed,
             mean=mean,
             stddev=stddev,
             m=m,
             k=k,
             q=q,
             print_batches=print_batches,
             print_results=print_results,
             save_results_to_file=save_results_to_file)  
