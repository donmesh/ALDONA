from Data_Reader import read_data
import collections
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import pandas as pd

def ontology_results(purpose, use_validation, print_results, save_results_to_file):
    path_data="../Data/Numpy/"
    path_results="../Results/"
    if use_validation:
        validation = "Validation_"
    else:
        validation = ""
        
    a = np.load(path_data+"Ontology_Results_"+validation+purpose+".npy")
    b = np.load(path_data+validation+purpose+"_polarity_vector.npy")
        
    pos_pos,pos_neu,pos_neg,neg_pos,neg_neu,neg_neg=0,0,0,0,0,0
        
    for i in range(len(a)):
        if (a[i].argmax() == 0) and (b[i].argmax()==0): pos_pos+=1
        if (a[i].argmax() == 0) and (b[i].argmax()==1): pos_neu+=1
        if (a[i].argmax() == 0) and (b[i].argmax()==2): pos_neg+=1
            
        if (a[i].argmax() == 2) and (b[i].argmax()==0): neg_pos+=1
        if (a[i].argmax() == 2) and (b[i].argmax()==1): neg_neu+=1
        if (a[i].argmax() == 2) and (b[i].argmax()==2): neg_neg+=1
                
    pos_pred = pos_pos + pos_neu + pos_neg
    neg_pred = neg_pos + neg_neu + neg_neg    
        
    pos_true = pos_pos + neg_pos
    neu_true = pos_neu + neg_neu
    neg_true = pos_neg + neg_neg    
    total = pos_true + neu_true + neg_true
        
    table = pd.DataFrame(data = [[pos_pos, pos_neu, pos_neg, "|", pos_pred], 
                                 [neg_pos, neg_neu, neg_neg, "|", neg_pred],
                                 ["--------", "-------", "--------", "-", "-----"],
                                 [pos_true, neu_true, neg_true, "|", total]],
                        index = ["Positive", "Negative", "--------", "total"], 
                        columns = ["Positive", "Neutral", "Negative", "|", "total"])
    if print_results:
        print("                  "+purpose+" Data")
        print(table)
        print("\n")
    if save_results_to_file:
        table.to_csv(path_results+"Ontology_"+validation+purpose+"_Results.csv")
            
def polarity_distribution():
    path_data="../Data/Numpy/"
    train = np.load(path_data+"Train_polarity_vector.npy")
    test = np.load(path_data+"Test_polarity_vector.npy")
    total_train = train.sum()
    total_test = test.sum()
    
    pa, neua, nega = train.sum(0)
    max_height = np.max([pa,neua,nega])
    pb, neub, negb = test.sum(0)
    
    pos_train = np.ones([pa])*0.2
    pos_test = np.ones([pb])*0.4
    neu_train = np.ones([neua])*0.9
    neu_test = np.ones([neub])*1.1
    neg_train = np.ones([nega])*1.6
    neg_test = np.ones([negb])*1.8
    
    fig = plt.figure("Polarity distribution", figsize=(8, 3))
    fig.set_size_inches(8, 3.3, forward=True)
    ax = fig.add_subplot(111)
    
    ax.spines["left"].set_position("zero")
    ax.spines["right"].set_color("none")
    ax.spines["top"].set_color("none")
    ax.spines["left"].set_smart_bounds(True)
    ax.spines["bottom"].set_smart_bounds(True)
    ax.xaxis.set_ticks([])
    ax.yaxis.set_ticks_position("left")
    ax.yaxis.set_label_text("Number of sentences")
    ax.set_ylim([0, max_height+100])
    
    green = sns.color_palette("dark", 2)[1]
    red = sns.color_palette("OrRd",10)[8]
    ax.hist(pos_train, label = "Train positive", color=green, hatch = "//")
    ax.hist(pos_test, label = "Test positive", color=green, hatch = "\\\\")
    ax.hist(neu_train, label = "Train neutral", color="grey", hatch = "//")
    ax.hist(neu_test, label = "Test neutral", color="grey", hatch = "\\\\")
    ax.hist(neg_train, label = "Train negative", color=red, hatch = "//")
    ax.hist(neg_test, label = "Test negative", color=red, hatch = "\\\\")
    
    ax.annotate("{}%".format(np.round(100*pa/total_train,2)), xy=(0.12, 1325))
    ax.annotate("{}%".format(np.round(100*pb/total_test,2)), xy=(0.35, 495))
    ax.annotate("{}%".format(np.round(100*neua/total_train,2)), xy=(0.85, 85))
    ax.annotate("{}%".format(np.round(100*neub/total_test,2)), xy=(1.05, 40))  
    ax.annotate("{}%".format(np.round(100*nega/total_train,2)), xy=(1.52, 502))
    ax.annotate("{}%".format(np.round(100*negb/total_test,2)), xy=(1.73, 150))
    plt.legend(loc="upper right")
    plt.show()

def aspect_categories():
    path_data_train="../Data/Train_data/"
    path_data_test="../Data/Test_data/"
    labels = np.char.array(['food#quality', 'food#style_options', 'food#prices',
                            'drinks#quality', 'drinks#style_options', 'drinks#prices',
                            'service#general', 'ambience#general', 'location#general',
                            'restaurant#general','restaurant#prices', 'restaurant#miscellaneous'])
    for purpose in ["Train", "Test"]:
        if purpose == "Train": data = path_data_train+"ABSA16_Restaurants_Train_SB1_v2.xml"
        else: data = path_data_test+"EN_REST_SB1_TEST.xml.gold" 
        reviews = read_data(data)
        
        categories=[]
        frequencies = []
        for r in reviews:
            for s in r.sentences:
                for o in s.opinions:
                    if o.target != None:
                        categories.append(o.category)
                    
        aspects = collections.Counter(categories)
        for cat in labels:
            frequencies.append(aspects[cat])
        fig = plt.figure("Aspect Categories " + purpose, figsize=[8,6])
        ax = fig.add_subplot(111)
        plt.tight_layout(rect=[0.1,0.05,0.9,0.85])      
        plt.title(purpose.title()+ " data", fontsize=15,y=1.05)
        ax.axis("equal")
        ax.pie(frequencies, labels=labels, colors = sns.color_palette("hls",12,0.7),
               startangle=180, radius=0.78, autopct="%1.0f%%", pctdistance=1.1,
               labeldistance=1.2)       
        plt.show()            

def activation_functions():
    sigmoid = lambda x: 1/(1+np.exp(-x))
    x = np.arange(-5,5,0.1)
    y= np.empty([2,100])
    y[0,:]= np.tanh(x)
    y[1,:] = sigmoid(x)
    i = 0
    for fun in ["tanh", "sigmoid"]:
        fig = plt.figure(fun)
        ax = fig.add_subplot(111)
        ax.plot(x,y[i,:])
    
        ax.spines["left"].set_position("zero")
        ax.spines["right"].set_color("none")
        ax.spines["bottom"].set_position("zero")
        ax.spines["top"].set_color("none")
        ax.spines["left"].set_smart_bounds(True)
        ax.spines["bottom"].set_smart_bounds(True)
        ax.xaxis.set_ticks_position("bottom")
        ax.yaxis.set_ticks_position("left")
    
        ax.axhline(linewidth = 0.5, color = "black")
        ax.axvline(linewidth = 0.5, color = "black")
        plt.title("y = "+fun+"(x)")
        plt.show()
        i += 1