import numpy as np

def get_embeddings(sentence_vector,target_vector,Glove_model):
    all_sentences = []
    i = 0
    max_len = 0
    for sentence in sentence_vector:
        target = target_vector[i]
        words = sentence.split()
        sentence_embedding = SentenceEmbedding()    
        sentence_embedding.sentence = sentence
        sentence_embedding.aspects = target
        sentence_embedding.sentence_len = len(words)
        if sentence_embedding.sentence_len > max_len:
            max_len = sentence_embedding.sentence_len
        for word in words:
            word_embedding = WordEmbedding()  
            word_embedding.word = word
            word_embedding.embedding = np.array(Glove_model.word_vec(word))
            sentence_embedding.embeddings.append(word_embedding.embedding)
            if word in target:
                sentence_embedding.aspect_embeddings.append(word_embedding.embedding)
        all_sentences.append(sentence_embedding)
        i += 1
    return all_sentences, max_len

def save_embeddings_to_files(all_sentences, N, purpose):
    path_data="../Data/Numpy/"
    d = len(all_sentences[0].embeddings[0])
    S = len(all_sentences)
    count = 0
    data_L = np.zeros((S,d,N)) 
    data_A = np.zeros((S,d,N)) 
    data_R = np.zeros((S,d,N))
    for sentence in all_sentences:
        index = sentence.sentence.find(sentence.aspects)
        S_LS = sentence.sentence[:index]
        left = list(range(len(S_LS.split())))
        aspect = list(range(len(left), len(left) + len(sentence.aspects.split())))
        right = list(range(len(left) + len(aspect), sentence.sentence_len))
        E = np.array(sentence.embeddings).transpose(1,0)
        data_L[count, :, left] = E[:, left].transpose(1,0)
        data_A[count, :, aspect] = E[:, aspect].transpose(1,0)
        data_R[count, :, right] = E[:, right].transpose(1,0)
        count += 1
    np.save(path_data+purpose+"_left_embedding_data.npy", data_L)
    np.save(path_data+purpose+"_aspect_embedding_data.npy", data_A)
    np.save(path_data+purpose+"_right_embedding_data.npy", data_R)
    
class SentenceEmbedding:
    def __init__(self):
        self.sentence,self.embeddings,self.aspects,self.aspect_embeddings = [],[],[],[]
        self.sentence_len = 0
        
    def __str__(self):    
        text = "Sentence: " + self.sentence + "\n"
        for word, embedding in zip(self.sentence.split(),self.embeddings):
            text += word + " " + str(embedding) + "\n"
        text += "Aspect embeddings:\n"
        for word,embedding in zip(self.aspects.split(),self.aspect_embeddings):
            text += word + " " + str(embedding) + "\n"
        return text
    
class WordEmbedding:
    def __init__(self):
        self.word,self.embedding = "",[]
    
    def __str__(self):
        return self.word + " " + str(self.embedding) + "\n"