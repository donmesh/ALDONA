from gensim.models import KeyedVectors
from gensim.scripts.glove2word2vec import glove2word2vec  

def save_glove_to_word2vec(in_file, out_file):
    glove2word2vec(in_file, out_file) # ~ 5 minutes

def load_glove_word2vec(file):
    model = KeyedVectors.load_word2vec_format(file, binary=False) # ~25 minutes
    return model

def save_vocabulary_list_to_file(file, model):
    with open(file, "w") as f:
        for key in list(model.vocab.keys()):
            f.write("{}\n".format(key.encode("raw_unicode_escape")))   

def read_vocabulary(file):
    keys=[]
    with open(file, "r") as f:
        for line in f:
            keys.append(line[2:-2]) 
    return keys




