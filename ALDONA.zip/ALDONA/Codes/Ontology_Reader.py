import owlready2 as OWL
import numpy as np
import nltk

def predict_sentiment(sentence, target, ontology, use_cabasc, majority, types, my_dict):
    words_in_sentence = sentence.split()
    word_lemmas_with_class,words_with_class,word_lemma_classes,target_class = get_class_of_words(words_in_sentence,target,my_dict)
    
    positive_class = ontology.search(iri="*Positive")[0]
    negative_class = ontology.search(iri="*Negative")[0]
    
    found_positive_list = []
    found_negative_list = []
    sentence_cabasc = False
    majority_count = 0
    for i in range(len(words_with_class)):
        word = words_with_class[i]
        word_lemma = word_lemmas_with_class[i]
        word_lemma_class = word_lemma_classes[i]
        negated = is_negated(word, words_in_sentence)
        if word_lemma in types[0]:
            found_positive,found_negative = get_class_sentiment(positive_class,negative_class,word_lemma_class,negated,False)
            found_positive_list.append(found_positive)
            found_negative_list.append(found_negative)
        if word_lemma in types[1]:
            if category_match(target_class, word_lemma_class):
                found_positive,found_negative = get_class_sentiment(positive_class,negative_class,word_lemma_class,negated,False)
                found_positive_list.append(found_positive)
                found_negative_list.append(found_negative)
        if word_lemma in types[2]:
            if target_class is None: new_class = word_lemma_class
            else: new_class = add_subclass(word_lemma_class, target_class)
            found_positive, found_negative = get_class_sentiment(positive_class,negative_class,new_class,negated,True)
            found_positive_list.append(found_positive)
            found_negative_list.append(found_negative) 
            
    if True in found_positive_list and True not in found_negative_list:
        prediction_vector = np.array([1, 0, 0]).reshape([1,-1])

    elif True not in found_positive_list and True in found_negative_list:
        prediction_vector = np.array([0, 0, 1]).reshape([1,-1])
    elif use_cabasc:
        sentence_cabasc = True
        prediction_vector = None
    else:
        prediction_vector = majority.reshape([1,-1])
        majority_count +=1
    return prediction_vector, sentence_cabasc, majority_count

def get_class_of_words(words_in_sentence, target, my_dict):
    word_lemma_classes,word_lemmas_with_class,words_with_class=[],[],[]
    target_class = None    
    Lemmatizer = nltk.WordNetLemmatizer()
    for word in words_in_sentence:
        word_tag = nltk.pos_tag(nltk.word_tokenize(word))[0][1]
        if word_tag.startswith("V"): word_lemma = Lemmatizer.lemmatize(word, "v")   # Verb
        elif word_tag.startswith("J"): word_lemma = Lemmatizer.lemmatize(word, "a") # Adjective
        elif word_tag.startswith("R"): word_lemma = Lemmatizer.lemmatize(word, "r") # Adverb
        else: word_lemma = Lemmatizer.lemmatize(word) # Other words do not change
    
        for ont_class in list(my_dict.values()):
            if word_lemma in ont_class:
                # To which class the word_lemma belongs
                word_lemma_class = list(my_dict.keys())[list(my_dict.values()).index(ont_class)]
                word_lemma_classes.append(word_lemma_class)
                word_lemmas_with_class.append(word_lemma)
                words_with_class.append(word)
                if word == target:
                    target_class = word_lemma_class
                break
    return word_lemmas_with_class,words_with_class,word_lemma_classes,target_class

def is_negated(word,words_in_sentence):
    negation = ({"not","no","never","isnt","arent","wont","wasnt","werent", 
                 "havent","hasnt", "nt", "cant", "couldnt", "dont", "doesnt"})
    negated = False
    index = words_in_sentence.index(word)
    check = set(words_in_sentence[max(index-3,0):index])
    if check.intersection(negation): negated = True
    return negated

def classes_into_types(classes):
    type1,type2,type3 = [],[],[]
    remove_words = ['property', "mention", "positive", "neutral", "negative"]
    for c in classes:
        class_name = c.__name__.lower()
        if any(word in class_name for word in remove_words): continue
        names=[]
        [names.append(x.__name__) for x in c.ancestors()]
        names.sort()
        for name in names:
            if "Generic" in name:
                type1.append(class_name)
                break
            elif any(x in name for x in ["Positive", "Negative"]):
                type2.append(class_name)
                break
            elif "PropertyMention" in name:
                type3.append(class_name)
                break
    return type1, type2, type3

def get_class_sentiment(positive_class,negative_class,word_lemma_class,negated,type3):
    found_positive,found_negative = False,False
    try:
        if type3: OWL.sync_reasoner() # To set relations of all new classes
        if positive_class.__subclasscheck__(word_lemma_class):
            found_positive = True
            if negated: 
                found_positive = False
                found_negative = True
    except Exception: pass
    try:
        if type3: OWL.sync_reasoner() # To set relations of all new classes
        if negative_class.__subclasscheck__(word_lemma_class):
            found_negative = True
            if negated: 
                found_negative = False
                found_positive = True
    except Exception: pass
    return found_positive,found_negative

def category_match(target_class,word_lemma_class):
    if target_class is None: return False
    target_mentions = []
    for ancestor in target_class.ancestors():
        if "Mention" in ancestor.__name__:
            target_mentions.append(ancestor.__name__.rsplit("Mention",1)[0])
    word_lemma_mentions = []
    for ancestor in word_lemma_class.ancestors():
        if "Mention" in ancestor.__name__:
            word_lemma_mentions.append(ancestor.__name__.rsplit("Mention",1)[0])
    common = set(target_mentions).intersection(set(word_lemma_mentions))
    # If they have more than 2 ancestors in common (ontology.Mention, ontology.EntityMention and something else)
    if len(common) > 2: return True 
    else: return False

def add_subclass(word_lemma_class, target_class):
    class_name = word_lemma_class.__name__ + target_class.__name__
    new_class = OWL.types.new_class(class_name, (word_lemma_class, target_class))
    return new_class

def get_majority_class(polarity_vector):
    total = polarity_vector.sum(0)
    index = np.argmax(total)
    if index == 0: return np.array([1, 0, 0])
    elif index == 1: return np.array([0, 1, 0])
    else: return np.array([0, 0, 1])