import GloVe
from Data_Processer import process_data, save_vectors
from Word_Embeddings import get_embeddings, save_embeddings_to_files
from sklearn.model_selection import train_test_split

def MainData(save_glove_word2vec_to_file,  	
                 read_glove_word2vec,           			
                 save_glove_word_list_to_file, 	
                 read_glove_word_list,          			
                 train_data,
                 test_data,    
                 save_train_data_vectors_to_files,
                 save_validation_train_data_vectors_to_files,
                 save_validation_test_data_vectors_to_files,
                 save_test_data_vectors_to_files,
                 validation_test_proportion,  
                 seed
                ):
########################## GloVe Files #################################   
    glove_file = "glove.42B.300d.txt"
    glove_word2vec_file = "glove.42B.300d.txt.word2vec"
    glove_words_file = "glove.42B.300d_keys.txt"
    
####################### Data Generation #################################
    path_data_train="../Data/Train_data/"
    path_data_test="../Data/Test_data/"
    path_data_glove="../Data/Glove/"
    if save_glove_word2vec_to_file:
        print("Saving GloVe to word2vec file...")
        GloVe.save_glove_to_word2vec(path_data_glove+glove_file, path_data_glove+glove_word2vec_file)
    if read_glove_word2vec:
        print("Reading GloVe as word2vec...")
        glove_model = GloVe.load_glove_word2vec(path_data_glove+glove_word2vec_file)
    if save_glove_word_list_to_file:
        print("Saving GloVe word list to file...")
        GloVe.save_vocabulary_list_to_file(path_data_glove+glove_words_file, glove_model)
    if read_glove_word_list:
        print("Reading GloVe word list...")
        glove_words = GloVe.read_vocabulary(path_data_glove+glove_words_file)
        
    print("Reading train data...")
    sentence_vector_train, target_vector_train, polarity_vector_train = process_data(path_data_train+train_data, glove_words, save_train_data_vectors_to_files, "Train")
    if validation_test_proportion > 0:
        (sentence_vector_validation_train, sentence_vector_validation_test, 
         target_vector_validation_train, target_vector_validation_test) = train_test_split(sentence_vector_train,
                                                                                           target_vector_train,
                                                                                           test_size=validation_test_proportion,
                                                                                           random_state=seed)
        
        polarity_vector_validation_train, polarity_vector_validation_test = train_test_split(polarity_vector_train, 
                                                                                            test_size=validation_test_proportion,
                                                                                            random_state=seed)
        if save_validation_train_data_vectors_to_files:
            save_vectors(sentence_vector_validation_train, target_vector_validation_train, polarity_vector_validation_train, "Validation_Train")
        if save_validation_test_data_vectors_to_files:
            save_vectors(sentence_vector_validation_test, target_vector_validation_test, polarity_vector_validation_test, "Validation_Test")
    print("Reading test data...")
    sentence_vector_test, target_vector_test, polarity_vector_test = process_data(path_data_test+test_data, glove_words, save_test_data_vectors_to_files, "Test")

    print("Getting train data embeddings...")
    all_sentences_train, max_len_train = get_embeddings(sentence_vector_train, target_vector_train, glove_model)
    if validation_test_proportion > 0:
        print("Getting validation train data embeddings...")
        all_sentences_validation_train, max_len_validation_train = get_embeddings(sentence_vector_validation_train, 
                                                                                  target_vector_validation_train, glove_model)
        print("Getting validation test data embeddings...")
        all_sentences_validation_test, max_len_validation_test = get_embeddings(sentence_vector_validation_test, 
                                                                                target_vector_validation_test, glove_model)
    print("Getting test data embeddings...")
    all_sentences_test, max_len_test = get_embeddings(sentence_vector_test, target_vector_test, glove_model)

    max_len = max(max_len_train, max_len_test)
    max_len_validation = max(max_len_validation_train, max_len_validation_test)
    
    print("Saving train data embeddings...")
    save_embeddings_to_files(all_sentences_train, max_len, "Train")
    if validation_test_proportion > 0:
        print("Saving validation train data embeddings ...")
        save_embeddings_to_files(all_sentences_validation_train, max_len_validation, "Validation_Train")
        print("Saving validation test data embeddings...")
        save_embeddings_to_files(all_sentences_validation_test, max_len_validation, "Validation_Test")
    print("Saving test data embeddings...")
    save_embeddings_to_files(all_sentences_test, max_len, "Test")