from MAIN_Data_Generator import MainData
from Visualization import polarity_distribution, aspect_categories, activation_functions
from Baseline_Models import Ont
from Optimization import optimize
from ALDONA_Classification import ALDONA

def MainProgram():
    ############################ PARAMETERS ###################################
    #################### Data Generation (once) ######################
    save_glove_word2vec_to_file = True   # <--- True only the first time (2-5 minutes)
    read_glove_word2vec = True           # <--- True everytime when new data should be generated (18-25 minutes)
    save_glove_word_list_to_file = True  # <--- True only the first time
    read_glove_word_list = True          # <--- True everytime when new data should be generated
    train_data = "ABSA16_Restaurants_Train_SB1_v2.xml"
    test_data = "EN_REST_SB1_TEST.xml.gold"    
    save_train_data_vectors_to_files = True
    save_validation_train_data_vectors_to_files = True
    save_validation_test_data_vectors_to_files = True
    save_test_data_vectors_to_files = True
    validation_test_proportion = 0.25                   # <----- The same proportion as in train-test
    seed_validation_split = 12345                       # <----- Cannot be None   
    generate_data=False              # <----- Takes around 20-30 minutes (MUST BE DONE AT LEAST ONCE)
    #################################################################
    ####################### Data Visualization ######################
    visualize_data=True 
    visualize_activation_functions=False
    
    ########################## Validation ###########################
    use_validation_data=True
    
    #################### Ontology Classification ####################
    testing_purpose="Test" # <------- testing will be performed on either "Train" or "Test" data
    print_ontology_results=True
    save_ontology_results_to_file=True
    
    ###################### Neural Networks ##########################
    test_model=True # <----- model is trained on "Train" data and tested on testing_purpose
    nr_epochs=100
    batch_size=128
    learning_rate=0.001
    keep_probability=0.7  # <------- oposite to dropout probability
    seed=None
    mean=0
    stddev=0.05
    m=300 # <------ Only applicablje for DBGRU or ALDONA  (Eq. 3.15)
    q=150
    k=150 # <------ Only applicable for DBGRU or ALDONA  (Eq. 3.18)
    
    print_train_results_for_every_batch=False
    print_train_test_results_for_every_epoch=True
    save_train_test_results_for_every_epoch_to_file=True
    
    ########################### Models #############################
    Ontology_classification=False
    BaseA_classification=False
    BaseB_classification=False
    BaseC_classification=False
    CABASC_classification=False
    CTX_LSTM_classification=False
    CTX_BLSTM_classification=False
    CTX_BGRU_classification=False
    DBGRU_classification=False  # <----- Neural Attention Model used in ALDONA
    ALDONA_classification=False
    
    
###############################################################################    
############################### OPTIMIZATION ##################################
    if generate_data:
        print("Generating data...")
        MainData(save_glove_word2vec_to_file = save_glove_word2vec_to_file,  	
                 read_glove_word2vec = read_glove_word2vec,           			
                 save_glove_word_list_to_file = save_glove_word_list_to_file, 	
                 read_glove_word_list = read_glove_word_list,          			
                 train_data = train_data,
                 test_data = test_data,    
                 save_train_data_vectors_to_files = save_train_data_vectors_to_files,
                 save_validation_train_data_vectors_to_files = save_validation_train_data_vectors_to_files,
                 save_validation_test_data_vectors_to_files = save_validation_test_data_vectors_to_files,
                 save_test_data_vectors_to_files = save_test_data_vectors_to_files,
                 validation_test_proportion = validation_test_proportion,  
                 seed = seed_validation_split
                )  
    
    if visualize_data:
        print("Visualizing data...")
        polarity_distribution()
        aspect_categories()
        
    if visualize_activation_functions:
        print("Visualizing activation functions...")
        activation_functions()
        
    if Ontology_classification:
        print("Ontology classification...")
        Ont(testing_purpose, use_validation_data, print_ontology_results, save_ontology_results_to_file)
    
    if BaseA_classification:
        print("BaseA classification...")
        optimize(test=test_model, 
                 use_validation=use_validation_data,
                 model="BaseA",
                 epochs=nr_epochs,
                 batch_size=batch_size,
                 learning_rate=learning_rate,
                 keep_probability=keep_probability,
                 seed=seed,
                 mean=mean,
                 stddev=stddev,
                 m=m,
                 q=q,
                 k=k,
                 print_batches=print_train_results_for_every_batch,
                 print_results=print_train_test_results_for_every_epoch,
                 save_results_to_file=save_train_test_results_for_every_epoch_to_file)        
    if BaseB_classification:
        print("BaseB classification...")
        optimize(test=test_model, 
                 use_validation=use_validation_data,
                 model="BaseB",
                 epochs=nr_epochs,
                 batch_size=batch_size,
                 learning_rate=learning_rate,
                 keep_probability=keep_probability,
                 seed=seed,
                 mean=mean,
                 stddev=stddev,
                 m=m,
                 q=q,
                 k=k,
                 print_batches=print_train_results_for_every_batch,
                 print_results=print_train_test_results_for_every_epoch,
                 save_results_to_file=save_train_test_results_for_every_epoch_to_file)
    if BaseC_classification:
        print("BaseC classification...")
        optimize(test=test_model, 
                 use_validation=use_validation_data,
                 model="BaseC",
                 epochs=nr_epochs,
                 batch_size=batch_size,
                 learning_rate=learning_rate,
                 keep_probability=keep_probability,
                 seed=seed,
                 mean=mean,
                 stddev=stddev,
                 m=m,
                 q=q,
                 k=k,
                 print_batches=print_train_results_for_every_batch,
                 print_results=print_train_test_results_for_every_epoch,
                 save_results_to_file=save_train_test_results_for_every_epoch_to_file)
    if CABASC_classification:
        print("CABASC classification...")
        optimize(test=test_model, 
                 use_validation=use_validation_data,
                 model="CABASC",
                 epochs=nr_epochs,
                 batch_size=batch_size,
                 learning_rate=learning_rate,
                 keep_probability=keep_probability,
                 seed=seed,
                 mean=mean,
                 stddev=stddev,
                 m=m,
                 q=q,
                 k=k,
                 print_batches=print_train_results_for_every_batch,
                 print_results=print_train_test_results_for_every_epoch,
                 save_results_to_file=save_train_test_results_for_every_epoch_to_file)
    if CTX_LSTM_classification:
        print("CTX-LSTM classification...")
        optimize(test=test_model, 
                 use_validation=use_validation_data,
                 model="CTX-LSTM",
                 epochs=nr_epochs,
                 batch_size=batch_size,
                 learning_rate=learning_rate,
                 keep_probability=keep_probability,
                 seed=seed,
                 mean=mean,
                 stddev=stddev,
                 m=m,
                 q=q,
                 k=k,
                 print_batches=print_train_results_for_every_batch,
                 print_results=print_train_test_results_for_every_epoch,
                 save_results_to_file=save_train_test_results_for_every_epoch_to_file)
    if CTX_BLSTM_classification:
        print("CTX-BLSTM classification...")
        optimize(test=test_model, 
                 use_validation=use_validation_data,
                 model="CTX-BLSTM",
                 epochs=nr_epochs,
                 batch_size=batch_size,
                 learning_rate=learning_rate,
                 keep_probability=keep_probability,
                 seed=seed,
                 mean=mean,
                 stddev=stddev,
                 m=m,
                 q=q,
                 k=k,
                 print_batches=print_train_results_for_every_batch,
                 print_results=print_train_test_results_for_every_epoch,
                 save_results_to_file=save_train_test_results_for_every_epoch_to_file)
    if CTX_BGRU_classification:
        print("CTX-BGRU classification...")
        optimize(test=test_model, 
                 use_validation=use_validation_data,
                 model="CTX-BGRU",
                 epochs=nr_epochs,
                 batch_size=batch_size,
                 learning_rate=learning_rate,
                 keep_probability=keep_probability,
                 seed=seed,
                 mean=mean,
                 stddev=stddev,
                 m=m,
                 q=q,
                 k=k,
                 print_batches=print_train_results_for_every_batch,
                 print_results=print_train_test_results_for_every_epoch,
                 save_results_to_file=save_train_test_results_for_every_epoch_to_file)
    if DBGRU_classification:
        print("Neural Attention Model (DBGRU) classification...")
        optimize(test=test_model, 
                 use_validation=use_validation_data,
                 model="DBGRU",
                 epochs=nr_epochs,
                 batch_size=batch_size,
                 learning_rate=learning_rate,
                 keep_probability=keep_probability,
                 seed=seed,
                 mean=mean,
                 stddev=stddev,
                 m=m,
                 q=q,
                 k=k,
                 print_batches=print_train_results_for_every_batch,
                 print_results=print_train_test_results_for_every_epoch,
                 save_results_to_file=save_train_test_results_for_every_epoch_to_file)
    if ALDONA_classification:
        print("ALDONA classification...")
        ALDONA(test=test_model, 
               use_validation=use_validation_data,
               epochs=nr_epochs,
               batch_size=batch_size,
               learning_rate=learning_rate,
               keep_probability=keep_probability,
               seed=seed,
               mean=mean,
               stddev=stddev,
               m=m,
               q=q,
               k=k,
               print_batches=print_train_results_for_every_batch,
               print_results=print_train_test_results_for_every_epoch,
               save_results_to_file=save_train_test_results_for_every_epoch_to_file)
        
if __name__ == "__main__":
    MainProgram()