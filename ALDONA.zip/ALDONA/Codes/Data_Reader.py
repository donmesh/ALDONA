import xml.etree.ElementTree as ET
import re

def read_data(file):
    tree = ET.parse(file)
    root = tree.getroot()
    reviews = []
    for R in root:
        review = Review()
        review.id = R.get("rid")
        for s in R.find("sentences").findall("sentence"):
            sentence = Sentence()
            sentence.review_id = review.id
            sentence.id = s.get("id")
            sentence.text = cleaning(s.find('text').text.lower())
            try: sentence.out_of_scope = s.get("OutOfScope")
            except Exception: sentence.out_of_scope = False
            try:
                for O in s.find("Opinions").findall("Opinion"):
                    opinion = Opinion()
                    try:
                        opinion.category = O.get("category").lower()
                        opinion.entity, opinion.attribute = opinion.category.split("#")
                    except Exception: opinion.category,opinion.entity,opinion.attribute = None,None,None
                    try: opinion.polarity = O.get("polarity").lower()
                    except Exception: opinion.polarity = None
                    try:
                        opinion.target = cleaning(O.get("target").lower())
                        if len(opinion.target) > len(sentence.text): opinion.target = "null"
                        if sentence.text.find(opinion.target) == -1: opinion.target = "null"
                        if opinion.target == "null": opinion.target = None
                        else:
                            opinion.start = int(O.get("from"))
                            opinion.end = int(O.get("to"))
                    except Exception: pass
                    sentence.opinions.append(opinion)
            except Exception: pass
            review.sentences.append(sentence)
        reviews.append(review)  
    return reviews

def cleaning(text):
    text = re.sub("(&quot;)", '"', text)
    text = re.sub("(&apos;)", "'", text)
    text = re.sub("(&amp;)", "and", text) 
    text = re.sub(r"[^\w\s]", " ", text)  # Replace punctuation with spaces
    text = re.sub("\d", "", text)         # Remove numbers
    text = re.sub("\s+", " ", text)       # Replace all spaces with 1 space
    text = re.sub("^\s+|\s+$", "", text)  # Remove spaces in the beginning and in the end
    return text


class Review:
    def __init__(self):
        self.id, self.sentences, self.opinions = None,[],[]
    def __str__(self):
        text = "Review [{}]\n".format(self.id)
        text += "Sentences:\n"
        for sentence in self.sentences:
            text += str(sentence) + "\n"
        if self.opinions:
            text += "Text_level Opinions:\n"
            for opinion in self.opinions:
                text += str(opinion) + "\n"
        return text
    
class Sentence:
    def __init__(self):
        self.review_id,self.id,self.text, = None,None,None
        self.out_of_scope,self.opinions = False,[]
    def __str__(self):
        text = "Sentence [{}]: '{}'\n".format(self.id,self.text)
        if self.opinions:
            text += "Sentnece-Level Opinions:\n"
            for opinion in self.opinions:
                text += str(opinion) + "\n"
        return text
    
class Opinion:
    def __init__(self):
        self.entity,self.attribute = None,None
        self.category,self.polarity,self.target = None,None,None
        self.start,self.end = None,None
    def __str__(self):
        if self.target:
            text = "[{}; {}] '{}' ({}-{})".format(self.category, self.polarity, self.target, self.start, self.end)
        else:
            text = "[{}; {}]".format(self.category, self.polarity)
        return text