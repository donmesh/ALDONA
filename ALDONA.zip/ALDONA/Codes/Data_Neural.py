import numpy as np
def data(purpose):
    path_data="../Data/Numpy/"
    data_LC = np.load(path_data+purpose+"_left_embedding_data.npy").astype(np.float32)
    data_A = np.load(path_data+purpose+"_aspect_embedding_data.npy").astype(np.float32)
    data_RC = np.load(path_data+purpose+"_right_embedding_data.npy").astype(np.float32)
    Y = np.load(path_data+purpose+"_polarity_vector.npy").astype(np.float32)
    E_LS = data_LC + data_A
    E_RS = data_A + data_RC
    E = data_LC + data_A + data_RC
    masks = {"left": data_LC != 0,
             "aspect": data_A != 0,
             "right": data_RC != 0,
             "left_with_aspect" : E_LS != 0,
             "right_with_aspect" : E_RS != 0,
             "sentence": E != 0}
    v_a = np.true_divide(data_A.sum(2), (data_A != 0).sum(2)).astype("float32")
    v_s = np.true_divide(E.sum(2), (E != 0).sum(2)).astype("float32")
    S,d,N = E.shape
    return E_LS, E_RS, E, v_a, v_s, masks, Y