from Data_Reader import read_data, cleaning
import numpy as np

def process_data(file_data, glove_vocab, save_vectors_to_files, data_purpose):
    sentence_vector,target_vector = [],[]
    polarity_vector = np.array([[0,0,0]])
    reviews = read_data(file_data)
    for review in reviews:
        for sentence in review.sentences:
            words = sentence.text.split()
            try:
                for opinion in sentence.opinions:
                    if opinion.target is not None:
                        for word in words:
                            try:  # Test if the word has embedding
                                glove_vocab.index(word)
                            except Exception:  # If word doesn't have embedding, remove that word
                                sentence.text = sentence.text.replace(word, "")
                                opinion.target = opinion.target.replace(word, "")
                        sentence.text = cleaning(sentence.text)
                        opinion.target = cleaning(opinion.target)
                        if opinion.target != "":
                            sentence_vector.append(sentence.text)
                            target_vector.append(opinion.target)
                            polar_vec = get_vector_polarity(opinion.polarity)
                            polarity_vector = np.append(polarity_vector, polar_vec, axis=0)
            except Exception:
                pass
    polarity_vector = np.delete(polarity_vector, 0, 0)
    sentence_vector = np.array(sentence_vector)
    target_vector = np.array(target_vector)
    if save_vectors_to_files:
        save_vectors(sentence_vector,target_vector,polarity_vector, data_purpose)
    return sentence_vector, target_vector, polarity_vector

def get_vector_polarity(polarity):
    if polarity == "positive":
        return np.array([[1, 0, 0]])
    elif polarity == "neutral":
        return np.array([[0, 1, 0]])
    elif polarity == "negative":
        return np.array([[0, 0, 1]])

def save_vectors(sentence, target, polarity, purpose):
    path_data="../Data/Numpy/"
    np.save(path_data+purpose+'_sentence_vector.npy', sentence)
    np.save(path_data+purpose+'_target_vector.npy', target)
    np.save(path_data+purpose+'_polarity_vector.npy', polarity)